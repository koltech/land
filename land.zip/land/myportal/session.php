<?php


$_SESSION['user'];
$_SESSION['pass'];



$_SESSION['name'];
$_SESSION['permanentaddress'];
$_SESSION['lga'];
$_SESSION['phonenum'];
$_SESSION['useridd'];

$name=$_SESSION['name'];
$permaddr=$_SESSION['permanentaddress'];
$lga=$_SESSION['lga'];
$userid=$_SESSION['useridd'];








?>