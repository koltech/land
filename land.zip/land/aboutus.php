<?php
include 'connect.php';
?>

<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    
    <title>About Us:Imo State Land Survey and Urban Planning</title>
    <!--  Bootstrap Style -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
     
    <link href="assets/css/font-awesome-animation.css" rel="stylesheet" />
     
    
        
    
     <!--  Custom Style -->
    <link href="assets/css/style.css" rel="stylesheet" />
    

</head>


<body>

   <div class="navbar navbar-default navbar-fixed-top menu-back">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <a class="navbar-brand" href="#">
                    <img src="logo1.png" class="navbar-brand-logo " alt="" />
                </a>
            </div>
            <div class="navbar-collapse collapse" >
                <ul class="nav navbar-nav navbar-right">
                   
                    <li class="dropdown">
                        <a href="index.php">HOME PAGE<i class="fa fa-folder-open-o"></i>
                            <span>Home</span>

                        </a>
                       
                    </li>
                    <li class="dropdown active">
                        <a href="aboutus.php">ABOUT US<i class="fa fa-folder-open-o"></i>
                            <span>Know Us</span>

                        </a>
                        
                    </li>

                    <li class="dropdown">
                        <a href="createaccount.php">REGISTER<i class="fa fa-user"></i>
                            <span>register with us</span>
                        </a>
                        
                    </li>

                   
                    <li class="dropdown">
                        <a href="login.php">CHECK REGISTERATION STATUS <i class="fa fa-bars"></i>
                            <span>Login first</span>
                        </a>
                        
                    </li>
                     <li class="dropdown ">
                        <a href="contact.php">CONTACT US <i class="fa fa-globe"></i>
                            <span>Any Problem?</span>
                        </a>

                    </li>
                </ul>
            </div>

        </div>
    </div>
    <!--./ Top Menu End -->
    <div class="div-social-top">

        <i class="fa fa-globe "></i>E-mail:  imslsup@myproject.com   | <i class="fa fa-mobile "></i>Call: : +2349036166195  |  <i class="fa fa-map-marker "></i>Country : Nigeria, Owerri &nbsp;
              <a href="#">
                  <i class="fa fa-facebook-square "></i>
              </a>


    </div>
    <!--./ Social Div End -->
	
	
	<div class="general-subhead">
        <h2>ABOUT US</h2>
    </div>
	
	 <section>
        <div class="container">
            <div class="row">
			
			
			<div class="col-md-4">
			<h4>Who We Are</h4><hr>
			<p></p>
			
			</div>
			
			
			<div class="col-md-4">
			<h4>What we do</h4><hr>
			<p></p>
			
			</div>
			
			<div class="col-md-4">
			<h4>What to Meet us</h4><hr>
			 <p>
                        Imo State Secretariat Road, New Owerri, Nigeria
                            <br />
                        Call: +234 903 616 6195
                            <br />
                        e-mail: imslsup@myproject.com
                             <br />
                    </p>
                    <h3>We Are Social</h3>
                    <a href="#"><i class="fa fa-facebook-square fa-3x color-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter-square fa-3x color-twitter"></i></a>
                    <a href="#"><i class="fa fa-google-plus-square fa-3x color-google-plus"></i></a>
			
			</div>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			 </div>
        </div>

    </section><br><br><br><br>
    <!--./ Main Contact end -->
	
	
	
	<div id="footser-end">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12">
                    2017 All Rights Reserved | by: <a href="" target="_blank" style="color:#fff" >Nwanezide Onyedikachi And Ohanwe Kasarachi</a>
                    
                </div>
            </div>

        </div>
    </div>
	
	