-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 13, 2017 at 04:11 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `land`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `documentation`
--

CREATE TABLE IF NOT EXISTS `documentation` (
`id` int(11) NOT NULL,
  `upn` varchar(500) NOT NULL,
  `img1` varchar(5000) NOT NULL,
  `img` varchar(500) NOT NULL,
  `userid` varchar(300) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `documentation`
--

INSERT INTO `documentation` (`id`, `upn`, `img1`, `img`, `userid`) VALUES
(1, 'fjirkfld,m', 'document/class.jpg', 'document/playground.jpg', 'KOL'),
(2, 'IMSLU/2017/827630131', 'document/playground.jpg', 'document/classy.jpg', 'IMLSUP/USER/3658905');

-- --------------------------------------------------------

--
-- Table structure for table `landuser`
--

CREATE TABLE IF NOT EXISTS `landuser` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `permanentaddr` text NOT NULL,
  `lga` text NOT NULL,
  `phone` varchar(15) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `userid` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `landuser`
--

INSERT INTO `landuser` (`id`, `name`, `email`, `permanentaddr`, `lga`, `phone`, `username`, `password`, `userid`) VALUES
(2, 'ononogbo kolade', 'ononogbokolade@yahoo.com', 'obokwu avu', 'Owerri West LGA', '08164269945', 'kolly', 'kolly', 'IMLSUP/USER/1389465'),
(3, 'goodnews kasarachi', 'kasaragoodnews@yahoo.com', 'orlu', 'owerri North', '07034735462', 'goodnews', '12345678', 'IMLSUP/USER/3658905');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `phone` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `name`, `email`, `message`, `phone`) VALUES
(1, 'kolade', 'ononogbokolly@gmail.com', 'good stuff', '09036166195');

-- --------------------------------------------------------

--
-- Table structure for table `regland`
--

CREATE TABLE IF NOT EXISTS `regland` (
`id` int(11) NOT NULL,
  `address_of_land` text NOT NULL,
  `lga` text NOT NULL,
  `acquisition_year` varchar(10) NOT NULL,
  `survey_date` varchar(50) NOT NULL,
  `holding_type` text NOT NULL,
  `current_land_use` text NOT NULL,
  `userid` varchar(200) NOT NULL,
  `certificate_number` varchar(500) NOT NULL,
  `holding_number` varchar(500) NOT NULL,
  `soil_fertility` text NOT NULL,
  `other_evidence` text NOT NULL,
  `encumbrance` text NOT NULL,
  `orthograph_num` varchar(20) NOT NULL,
  `upn` varchar(500) NOT NULL,
  `date_registered` varchar(50) NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `regland`
--

INSERT INTO `regland` (`id`, `address_of_land`, `lga`, `acquisition_year`, `survey_date`, `holding_type`, `current_land_use`, `userid`, `certificate_number`, `holding_number`, `soil_fertility`, `other_evidence`, `encumbrance`, `orthograph_num`, `upn`, `date_registered`, `status`) VALUES
(3, 'Obokwu Avu', 'Owerri West LGA', '2006', '12/12/2013', 'Communal', 'Rainfred', 'KOL', 'IMSLU/256MD/MIG', 'IMSLU/703063MDMLIS/HOLDER', 'Medium', 'None', 'terms of Right', '2', 'IMSLU/2017/1205697600', '08/10/17', 'Pending'),
(4, 'Obokwu Avu', 'Owerri West LGA', '2006', '12/12/2013', 'Communal', 'Rainfred', 'KOL', 'IMSLU/256MD/MIG', 'IMSLU/334655ILSMMD/HOLDER', 'Medium', 'None', 'terms of Right', '2', 'IMSLU/2017/257968902', '08/10/17', 'registered'),
(7, 'abuja', 'owerri North', '1998', '12/12/2013', 'Private', 'Rainfred', 'IMLSUP/USER/1389465', 'ert/2014/IMSLU', 'IMSLU/175720ISMMLD/HOLDER', 'Rich', 'None', 'Interest', '7', 'IMSLU/2017/431605384', '08/10/17', 'Pending'),
(8, 'owerri municpal', 'owerri municipal', '2005', '12/12/2014', 'Private', 'fm', 'IMLSUP/USER/3658905', 'GH/ERR/IMSLU', 'IMSLU/343994IMMDLS/HOLDER', 'Medium', 'None', 'terms of Right', '5', 'IMSLU/2017/827630131', '09/10/17', 'Registered');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documentation`
--
ALTER TABLE `documentation`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `landuser`
--
ALTER TABLE `landuser`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `regland`
--
ALTER TABLE `regland`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `documentation`
--
ALTER TABLE `documentation`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `landuser`
--
ALTER TABLE `landuser`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `regland`
--
ALTER TABLE `regland`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
