
<?php
include 'connect.php';
?>

<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    
    <title>Imo State Land Survey and Urban Planning</title>
    <!--  Bootstrap Style -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
     
    <link href="assets/css/font-awesome-animation.css" rel="stylesheet" />
     
    
        
    
     <!--  Custom Style -->
    <link href="assets/css/style.css" rel="stylesheet" />
    

</head>
<script>
function checkAvailability() {
	$("#loaderIcon").show();
	jQuery.ajax({
	url: "check_availability.php",
	data:'user='+$("#username").val(),
	type: "POST",
	success:function(data){
		$("#user-availability-status").html(data);
		$("#loaderIcon").hide();
	},
	error:function (){}
	});
}
</script>

<body>

   <div class="navbar navbar-default navbar-fixed-top menu-back">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <a class="navbar-brand" href="#">
                    <img src="logo1.png" class="navbar-brand-logo " alt="" />
                </a>
            </div>
            <div class="navbar-collapse collapse" >
                <ul class="nav navbar-nav navbar-right">
                   
                    <li class="dropdown">
                        <a href="index.php">HOME PAGE<i class="fa fa-folder-open-o"></i>
                            <span>Home</span>

                        </a>
                       
                    </li>
                    <li class="dropdown">
                        <a href="aboutus.php">ABOUT US<i class="fa fa-folder-open-o"></i>
                            <span>Know Us</span>

                        </a>
                        
                    </li>

                    <li class="dropdown active">
                        <a href="createaccount.php">REGISTER<i class="fa fa-user"></i>
                            <span>register with us</span>
                        </a>
                        
                    </li>

                   
                    <li class="dropdown">
                        <a href="login.php">CHECK REGISTERATION STATUS <i class="fa fa-bars"></i>
                            <span>Login first</span>
                        </a>
                        
                    </li>
                     <li class="dropdown">
                        <a href="contact.php">CONTACT US <i class="fa fa-globe"></i>
                            <span>Any Problem?</span>
                        </a>

                    </li>
                </ul>
            </div>

        </div>
    </div>
    <!--./ Top Menu End -->
    <div class="div-social-top">

        <i class="fa fa-globe "></i>E-mail:  imslsup@myproject.com   | <i class="fa fa-mobile "></i>Call: : +2349036166195  |  <i class="fa fa-map-marker "></i>Country : Nigeria, Owerri &nbsp;
              <a href="#">
                  <i class="fa fa-facebook-square "></i>
              </a>


    </div>
    <!--./ Social Div End -->
	
	
	<div class="general-subhead">
        <h4>Dont have an Account?..Create One Now</h4>
    </div>
    <!--./ Gereral Subhead End -->
    <section>
        <div class="container">
            <div class="row">

               
                <div class="col-lg-6 col-md-6  col-sm-12">
                    
                    <hr />
                    <form action="" method="POST">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="name" required="required" placeholder="Name" />
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <input type="mail" class="form-control" name="email" placeholder="Email address" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="pa" required="required" placeholder="Permanent Adress" />
                                </div>
								<div class="form-group">
                                    <input type="text" class="form-control" required="required" name="lga" placeholder="Local Government Area" />
                                </div>
								<div class="row">
								<div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="phone" required="required" placeholder="Phone Number" />
                                </div>
                            </div>
							<div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="user" onBlur="checkAvailability()" id="username" required="required" placeholder="Username" />
									<span id="user-availability-status"></span>
                                </div>
                            </div> 
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="form-group">
                                    <input type="password" class="form-control" required="required" name="pass" placeholder="Password" />
                                </div>
                            </div> 
							</div>
								
								
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary" name="create">Create Account</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

				<?php
			 
				 if (isset($_POST['create'])){

$name=$_POST['name'];
$addr=$_POST['pa'];
$mail=$_POST['email'];
$phone=$_POST['phone'];
$lga=$_POST['lga'];

$user=$_POST['user'];
$pass=$_POST['pass'];

$landuser="IMLSUP/USER/";
$generate=rand(0,5000000);
$userid=$landuser.$generate;





$check2=mysqli_query($con,"select * from landuser where username='$user' ");

	$row2=mysqli_num_rows($check2);
	
	if($row2 > 0 ){
		 echo"<script>alert('this user have been enrolled already,please try again')</script>";
		 
	}
	
	else{
		if($row2==0){
		$senddata2 = mysqli_query($con,"insert into landuser (name,email,permanentaddr,lga,phone,username,password,userid) values
	('".mysqli_real_escape_string($con,$name)."','".mysqli_real_escape_string($con,$mail)."','".mysqli_real_escape_string($con,$addr)."',
	'".mysqli_real_escape_string($con,$lga)."','".mysqli_real_escape_string($con,$phone)."','".mysqli_real_escape_string($con,$user)."',
	'".mysqli_real_escape_string($con,$pass)."','$userid')")or die(mysql_error()); 
	
		}
}
	if(@$senddata2){
		
	echo"<script>alert('$name, you enrolled succesfully')</script>";
}

else{
echo"<script>alert('An error occured,please try again..')</script>";	
}
	
}
	?>
				
				
				
				
            </div>
        </div>

    </section>
    <!--./ Main Contact end -->
	
	
	
	<div id="footser-end">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12">
                    2017 All Rights Reserved | by: <a href="" target="_blank" style="color:#fff" >Nwanezide Onyedikachi And Ohanwe Kasarachi</a>
                    
                </div>
            </div>

        </div>
    </div>
	
	
	
	
	
	
	
	
	
	
	<!--  Jquery Core Script -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!--  Core Bootstrap Script -->
    <script src="assets/js/bootstrap.js"></script>
        <!--  Custom Scripts -->
    <script src="assets/js/custom.js"></script>
   
</body>
</html>
	
	
	