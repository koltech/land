<?php
$con=mysqli_connect("localhost","root","","land") or die(mysqli_error());

?>